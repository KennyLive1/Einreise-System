--[[
    Config.lua – Einreise-System (ESX Legacy, oxmysql)

    Diese Datei wird von Client UND Server geladen (shared_script).
    Hier steht nichts Geheimes drin – Webhook-URLs also bitte nur dann eintragen,
    wenn du damit leben kannst, dass sie technisch auch am Client ankommen.
    (Empfehlung: Webhook nur über eine server.cfg-Convar lösen, siehe README.)
]]

Config = {}

-- ============================================================================
--  ALLGEMEIN
-- ============================================================================

-- Zusätzliche Debug-Ausgaben in der Konsole
Config.Debug = false

-- Status für Charaktere, die noch keinen Datenbankeintrag haben.
-- false = neue Spieler müssen erst einreisen (Standard)
-- true  = neue Spieler gelten automatisch als eingereist
Config.DefaultEntered = false

-- Dürfen Teamler sich selbst per /einreise einreisen lassen?
Config.AllowSelfGrant = true

-- ============================================================================
--  FLUGHAFEN / EINREISEBEREICH
-- ============================================================================

-- Mittelpunkt und Radius der Sperrzone (Standard: Flughafen Los Santos, LSIA).
-- Gemessen wird die Entfernung in der Ebene (X/Y), die Höhe spielt keine Rolle.
Config.Airport = {
    center = vector3(-1037.0, -2737.0, 20.17),
    radius = 200.0 -- Meter
}

-- Hierhin werden nicht eingereiste Spieler zurückgebracht (x, y, z, Blickrichtung).
-- WICHTIG: Der Punkt muss innerhalb des Sperrradius liegen!
Config.ReturnPoint = vector4(-1037.5, -2737.8, 20.17, 328.0)

-- ============================================================================
--  CLIENT-VERHALTEN
-- ============================================================================

Config.Client = {
    checkInterval    = 250,   -- ms zwischen zwei Positionsprüfungen (nur für nicht eingereiste Spieler)
    warnDistance     = 30.0,  -- Ab so vielen Metern vor der Grenze erscheint ein Warnhinweis
    fade             = true,  -- Bildschirm beim Zurückteleportieren ein-/ausblenden
    reminderInterval = 300    -- Sekunden zwischen Erinnerungs-Hinweisen (0 = aus)
}

-- Kreis auf der Karte, der die Sperrzone für nicht eingereiste Spieler anzeigt
Config.Blip = {
    enabled = true,
    color   = 1,   -- 1 = rot
    alpha   = 80   -- 0-255
}

-- ============================================================================
--  SERVER-SICHERHEITSPRÜFUNG
-- ============================================================================
-- Der Server kontrolliert nicht eingereiste Spieler unabhängig vom Client.
-- Damit hilft das Skript auch gegen manipulierte Clients (Noclip, Teleport-Cheats ...).
-- Benötigt OneSync, damit der Server die Spielerposition kennt.

Config.Server = {
    checkInterval = 2500, -- ms zwischen zwei Prüfungen
    tolerance     = 15.0, -- Meter Toleranz über dem Radius, bevor der Server eingreift
    forceAfter    = 2     -- Ab dem wievielten Verstoß in Folge der Server selbst teleportiert
                          -- (1 = sofort; davor wird zuerst der Client aufgefordert, sich selbst zurückzusetzen)
}

-- ============================================================================
--  BEFEHLE
-- ============================================================================

Config.Commands = {
    grant  = 'einreise',        -- /einreise [Spieler-ID]        -> Einreise freigeben
    revoke = 'einreiseentzug',  -- /einreiseentzug [Spieler-ID]  -> Einreise widerrufen (z. B. zum Testen)
    status = 'einreisestatus',  -- /einreisestatus [Spieler-ID]  -> Status abfragen
    outfit = 'einreiseoutfit'   -- /einreiseoutfit [aus]         -> Beamten-Outfit an/aus
}

-- ============================================================================
--  BERECHTIGUNGEN
-- ============================================================================
-- Ein Spieler darf den Befehl nutzen, wenn EINE der folgenden Bedingungen zutrifft:
--   1. ace    : Er besitzt die ACE-Berechtigung (z. B. per add_ace in der server.cfg)
--   2. groups : Seine ESX-Gruppe steht in der Liste (user, mod, admin, superadmin, eigene ...)
--   3. jobs   : Sein Job steht in der Liste und sein Rang ist mindestens so hoch wie angegeben
-- Nicht benötigte Teile einfach leer lassen ('' bzw. {}).
-- Die Serverkonsole (Quelle 0) darf immer alles.

Config.Permissions = {
    -- Teamler-Befehle: /einreise, /einreiseentzug, /einreisestatus
    manage = {
        ace    = 'einreise.manage',
        groups = { 'mod', 'admin', 'superadmin' },
        jobs   = {} -- z. B. { immigration = 2 }
    },

    -- Geschützter Befehl /einreiseoutfit
    outfit = {
        ace    = 'einreise.outfit',
        groups = { 'mod', 'admin', 'superadmin' },
        jobs   = { immigration = 0 } -- Jobname = Mindest-Rang (0 = jeder Rang)
    }
}

-- ============================================================================
--  EINREISEBEAMTEN-OUTFIT
-- ============================================================================
-- 'auto'        = skinchanger, falls gestartet, sonst nativ
-- 'skinchanger' = esx_skin / skinchanger (Standard bei ESX Legacy)
-- 'native'      = reine GTA-Natives (funktioniert nur mit den Freemode-Peds mp_m/mp_f_freemode_01)
Config.OutfitSystem = 'auto'

-- Beispielwerte im Stil einer Behörden-Uniform. Die Nummern hängen von deinen
-- Kleidungs-Packs ab – bitte im Spiel testen und anpassen.
-- Schlüssel entsprechen den skinchanger-Namen (_1 = Variante, _2 = Textur).
-- helmet/glasses/ears: -1 = Gegenstand ablegen.
Config.Outfit = {
    male = {
        tshirt_1 = 59, tshirt_2 = 0,
        torso_1  = 55, torso_2  = 0,
        decals_1 = 0,  decals_2 = 0,
        arms     = 41, arms_2   = 0,
        pants_1  = 25, pants_2  = 1,
        shoes_1  = 25, shoes_2  = 0,
        helmet_1 = -1, helmet_2 = 0,
        chain_1  = 0,  chain_2  = 0,
        ears_1   = 2,  ears_2   = 0
    },
    female = {
        tshirt_1 = 36, tshirt_2 = 1,
        torso_1  = 48, torso_2  = 0,
        decals_1 = 0,  decals_2 = 0,
        arms     = 44, arms_2   = 0,
        pants_1  = 34, pants_2  = 0,
        shoes_1  = 27, shoes_2  = 0,
        helmet_1 = -1, helmet_2 = 0,
        chain_1  = 0,  chain_2  = 0,
        ears_1   = 2,  ears_2   = 0
    }
}

-- ============================================================================
--  DISCORD-LOG (optional)
-- ============================================================================
Config.Webhook = {
    enabled = false,
    url     = '',
    name    = 'Einreise-System'
}

-- ============================================================================
--  TEXTE (Deutsch)
-- ============================================================================
-- %s sind Platzhalter – ihre Reihenfolge bitte nicht ändern.

Config.Text = {
    -- Teamler / Fehler
    no_permission   = 'Dazu hast du keine Berechtigung.',
    usage           = 'Benutzung: /%s [Spieler-ID]',
    target_offline  = 'Spieler-ID %s ist nicht online oder noch nicht vollständig geladen.',
    self_denied     = 'Du darfst dich nicht selbst einreisen lassen.',
    already_entered = '%s (ID %s) ist bereits eingereist.',
    not_entered     = '%s (ID %s) ist nicht eingereist.',
    granted_staff   = 'Du hast %s (ID %s) einreisen lassen.',
    granted_target  = 'Deine Einreise wurde von %s freigegeben. Willkommen in Los Santos!',
    revoked_staff   = 'Die Einreise von %s (ID %s) wurde widerrufen.',
    revoked_target  = 'Deine Einreise wurde widerrufen. Bitte begib dich in den Einreisebereich.',
    status_entered  = '%s (ID %s) ist eingereist.',
    status_pending  = '%s (ID %s) ist NICHT eingereist.',
    db_error        = 'Datenbankfehler: Der Status konnte nicht gespeichert werden (siehe Serverkonsole).',

    -- Spieler
    not_entered_info = 'Du bist noch nicht eingereist. Bitte warte im Einreisebereich auf einen Einreisebeamten.',
    left_area        = 'Du darfst den Flughafen erst nach der Einreise verlassen. Du wurdest zurückgebracht.',
    warn_border      = 'Flughafengrenze – Verlassen erst nach der Einreise erlaubt!',

    -- Outfit
    outfit_console     = 'Dieser Befehl kann nur im Spiel genutzt werden.',
    outfit_cooldown    = 'Bitte warte kurz, bevor du den Befehl erneut nutzt.',
    outfit_on          = 'Einreisebeamten-Outfit angezogen. Mit /einreiseoutfit aus stellst du dein Outfit wieder her.',
    outfit_off         = 'Dein vorheriges Outfit wurde wiederhergestellt.',
    outfit_none        = 'Es ist kein gespeichertes Outfit vorhanden.',
    outfit_unsupported = 'Dein Charaktermodell unterstützt das Outfit nicht (nur Freemode-Peds).',

    -- Chat-Vorschläge
    sugg_grant     = 'Spieler einreisen lassen',
    sugg_revoke    = 'Einreise eines Spielers widerrufen',
    sugg_status    = 'Einreisestatus eines Spielers anzeigen',
    sugg_id_help   = 'Server-ID des Spielers',
    sugg_outfit    = 'Einreisebeamten-Outfit an-/ausziehen',
    sugg_outfit_help = 'Optional: "aus" stellt dein altes Outfit wieder her'
}
