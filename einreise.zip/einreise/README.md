# Einreise-System für ESX Legacy

Ein Einreisesystem für FiveM-Server mit ESX Legacy und oxmysql. Neue Spieler landen im Flughafen und dürfen ihn erst verlassen, wenn ein Teamler sie per Befehl einreisen lässt. Der Status wird dauerhaft in der Datenbank gespeichert.

## Funktionen

- **Sperrradius** (Standard 200 m um den Flughafen Los Santos), frei konfigurierbar
- **Automatisches Zurückteleportieren** nicht eingereister Spieler in den Einreisebereich
- **Dauerhafter Status** pro Charakter in der Datenbank (`einreise_status`)
- **Teamler-Befehl** `/einreise [Spieler-ID]`
- **Geschützter Befehl** `/einreiseoutfit` für Einreisebeamten-Kleidung, inklusive Wiederherstellung des vorherigen Outfits
- **Konfigurierbare Berechtigungen** über ACE, ESX-Gruppen und Jobs mit Mindest-Rang
- **Serverseitige Sicherheitsprüfung**: Der Server kontrolliert die echte Spielerposition unabhängig vom Client
- Karten-Kreis für nicht eingereiste Spieler, Warnhinweis kurz vor der Grenze, Erinnerungshinweise
- Optionaler Discord-Log
- Exports für andere Skripte

## Voraussetzungen

| Voraussetzung | Hinweis |
|---|---|
| `es_extended` | ESX Legacy (1.9 oder neuer empfohlen) |
| `oxmysql` | Wird für alle Datenbankzugriffe genutzt |
| OneSync | Der Server braucht die Spielerposition für die Sicherheitsprüfung (`set onesync on`) |
| `skinchanger` / `esx_skin` | Optional. Ohne sie nutzt das Outfit-System nativ die Freemode-Peds |

## Installation

1. Den Ordner `einreise` in deinen Resources-Ordner legen, z. B. `resources/[esx]/einreise/`. Er muss diese Dateien enthalten: `fxmanifest.lua`, `Config.lua`, `client.lua`, `server.lua` und `einreise.sql`.
2. **`einreise.sql`** in deine ESX-Datenbank importieren.
3. In der `server.cfg` die Resource nach `es_extended` und `oxmysql` starten:

   ```cfg
   ensure oxmysql
   ensure es_extended
   ensure skinchanger
   ensure esx_skin
   ensure einreise
   ```

4. Berechtigungen festlegen (siehe unten) und `Config.lua` anpassen.
5. Server neu starten oder `ensure einreise` in der Konsole ausführen.

> **Bestehende Spieler:** Mit `Config.DefaultEntered = false` gelten alle Charaktere ohne Datenbankeintrag beim ersten Login als nicht eingereist, auch alte Spieler. Wenn das nicht gewünscht ist, entferne am Ende von `einreise.sql` die Kommentarzeichen beim optionalen `INSERT`. Dann werden alle vorhandenen Charaktere als eingereist markiert.

> **Standard-Spawn:** Setze den Standard-Spawn neuer Charaktere (ESX bzw. `esx_multicharacter`) auf den Flughafen. Das Skript teleportiert nicht eingereiste Spieler zwar automatisch in den Einreisebereich, ein passender Spawn sieht aber sauberer aus.

## Befehle

| Befehl | Wer | Beschreibung |
|---|---|---|
| `/einreise [Spieler-ID]` | Teamler (`manage`) | Gibt die Einreise des Spielers frei. Der Status wird dauerhaft gespeichert. |
| `/einreiseentzug [Spieler-ID]` | Teamler (`manage`) | Widerruft die Einreise, z. B. zum Testen. |
| `/einreisestatus [Spieler-ID]` | Teamler (`manage`) | Zeigt an, ob der Spieler eingereist ist. |
| `/einreiseoutfit` | Berechtigte (`outfit`) | Zieht das Einreisebeamten-Outfit an. Ein zweiter Aufruf stellt das vorherige Outfit wieder her. |
| `/einreiseoutfit aus` | Berechtigte (`outfit`) | Stellt das vorherige Outfit immer wieder her. |

Die Befehlsnamen lassen sich in `Config.Commands` ändern. Die Serverkonsole darf `/einreise`, `/einreiseentzug` und `/einreisestatus` immer nutzen.

## Berechtigungen

In `Config.Permissions` gibt es zwei Gruppen: `manage` (Teamler-Befehle) und `outfit` (Outfit-Befehl). Ein Spieler darf einen Befehl nutzen, wenn **eine** dieser Bedingungen zutrifft:

1. **ACE:** Er besitzt die ACE-Berechtigung (`einreise.manage` bzw. `einreise.outfit`).
2. **ESX-Gruppe:** Seine Gruppe steht in `groups` (z. B. `mod`, `admin`, `superadmin` oder eine eigene Gruppe wie `support`).
3. **Job:** Sein Job steht in `jobs` und sein Rang ist mindestens so hoch wie angegeben.

```lua
Config.Permissions = {
    manage = {
        ace    = 'einreise.manage',
        groups = { 'mod', 'admin', 'superadmin' },
        jobs   = { immigration = 2 }   -- Job "immigration" ab Rang 2
    },
    outfit = {
        ace    = 'einreise.outfit',
        groups = { 'admin', 'superadmin' },
        jobs   = { immigration = 0 }   -- Job "immigration", jeder Rang
    }
}
```

Beispiel für ACE-Rechte in der `server.cfg`:

```cfg
add_ace group.admin einreise.manage allow
add_ace group.admin einreise.outfit allow
add_principal identifier.license:DEINELIZENZ group.admin
```

Nicht benötigte Teile lässt du leer (`ace = ''`, `groups = {}`, `jobs = {}`).

## So funktioniert es

**Nicht eingereiste Spieler**

- Beim Login lädt der Server den Status aus der Datenbank und schickt ihn an den Client. Neue Charaktere bekommen automatisch einen Eintrag.
- Der Client prüft alle 250 ms (`Config.Client.checkInterval`), ob der Spieler noch im Sperrradius ist. Verlässt er ihn, wird er mit kurzer Ausblendung zurück in den Einreisebereich (`Config.ReturnPoint`) gebracht. Fahrer nehmen ihr Fahrzeug mit.
- Kurz vor der Grenze erscheint ein Warnhinweis. Auf der Karte ist die Sperrzone als roter Kreis markiert.

**Nach der Freigabe**

- Ein Teamler gibt per `/einreise [ID]` frei. Der Server schreibt den Status in die Datenbank und informiert den Spieler.
- Eingereiste Spieler werden nicht mehr überwacht und dürfen den Flughafen frei verlassen. Der Status bleibt auch nach Relog und Neustart erhalten.

## Sicherheit

- Der Einreisestatus kann **nur der Server** ändern. Es gibt kein Client-Event, das den Status setzt. Der Client darf lediglich seinen eigenen Status abfragen (mit Spam-Schutz).
- Alle Befehle prüfen die Berechtigung auf dem Server. `/einreiseoutfit` schickt dem Client den Auftrag erst nach erfolgreicher Prüfung.
- **Serverseitige Positionsprüfung** (`Config.Server`): Der Server liest alle 2,5 Sekunden die echte Position aller nicht eingereisten Spieler.
  - Beim ersten Verstoß wird der Client aufgefordert, sich zurückzusetzen.
  - Reagiert er nicht (ab `forceAfter` Verstößen in Folge), teleportiert der Server den Spieler selbst und schreibt einen Log-Eintrag.
  - Ein manipulierter Client kann sich dem also nicht durch das Ausschalten der Client-Skripte entziehen.
- Der Status wird pro **Charakter** (ESX-Identifier) gespeichert. Mit `esx_multicharacter` muss also jeder neue Charakter einmal einreisen.

## Outfit-System

- `Config.OutfitSystem = 'auto'` nutzt `skinchanger` (esx_skin), falls gestartet, sonst nativ. Im nativen Modus funktionieren nur die Freemode-Peds `mp_m_freemode_01` und `mp_f_freemode_01`.
- Die Kleidungsnummern in `Config.Outfit` sind **Beispielwerte**. Sie hängen von deinen Kleidungs-Packs ab. Teste sie im Spiel und passe sie an. Für Mützen, Brillen und Ohrschmuck bedeutet `-1`, dass das Teil abgelegt wird.
- Das vorherige Outfit wird beim Anziehen als Kopie gesichert und mit `/einreiseoutfit` (zweiter Aufruf) oder `/einreiseoutfit aus` wiederhergestellt.
- Das Beamten-Outfit wird **nicht** in der Datenbank gespeichert. Beim Charakterwechsel (`esx:onPlayerLogout`) wird das alte Outfit automatisch zurückgeholt. Nach einem Tod oder Relog gilt das normale Outfit des Spielers.
- Speichert dein Server die Kleidung automatisch beim Ausloggen, empfiehlt es sich, das Outfit vorher auszuziehen.

## Wichtige Einstellungen in der Config.lua

| Einstellung | Bedeutung |
|---|---|
| `Config.Airport.center` / `radius` | Mittelpunkt und Radius der Sperrzone (Standard 200 m) |
| `Config.ReturnPoint` | Rückkehrpunkt im Einreisebereich. Er muss **innerhalb** des Radius liegen. |
| `Config.DefaultEntered` | Status für Charaktere ohne Datenbankeintrag |
| `Config.Client.*` | Prüfintervall, Warnabstand, Ausblenden, Erinnerungsintervall |
| `Config.Server.*` | Intervall, Toleranz und Eskalation der Sicherheitsprüfung |
| `Config.Blip` | Karten-Kreis für nicht eingereiste Spieler |
| `Config.Webhook` | Discord-Log (der Webhook liegt in einer geteilten Datei, siehe Hinweis in `Config.lua`) |
| `Config.Text` | Alle Meldungen auf Deutsch, frei anpassbar |

Die Koordinaten sind für den Flughafen Los Santos (LSIA) voreingestellt. Für einen eigenen Einreisebereich (z. B. in einem MLO) passt du `center` und `ReturnPoint` an.

## Exports

```lua
-- Client
local entered = exports['einreise']:IsEntered()           -- true / false / nil (unbekannt)

-- Server
local entered = exports['einreise']:IsEntered(source)     -- true / false
local ok      = exports['einreise']:SetEntered(source, true, 'mein_skript')
```

## Fehlersuche

| Problem | Lösung |
|---|---|
| Konsole meldet „Tabelle einreise_status fehlt" | `einreise.sql` importieren. |
| Spieler wird nicht zurückteleportiert | Läuft `einreise` nach `es_extended`? Ist der Spieler wirklich nicht eingereist (`/einreisestatus [ID]`)? |
| Server greift nie ein | OneSync aktivieren (`set onesync on`). Ohne OneSync kennt der Server die Spielerposition nicht. |
| Spieler hängt in einer Teleport-Schleife | `Config.ReturnPoint` liegt außerhalb des Radius. Punkt oder Radius anpassen. |
| Befehl meldet „keine Berechtigung" | ACE, ESX-Gruppe oder Job prüfen (`Config.Permissions`). Mit `Config.Debug = true` gibt es zusätzliche Ausgaben. |
| Outfit sieht falsch aus | Kleidungsnummern in `Config.Outfit` an deine Kleidungs-Packs anpassen. |
| Nach Resource-Neustart ist der Status unbekannt | Das Skript synchronisiert online befindliche Spieler automatisch. Falls nicht, ist die Datenbank beim Start noch nicht bereit. Dann `ensure einreise` erneut ausführen. |
