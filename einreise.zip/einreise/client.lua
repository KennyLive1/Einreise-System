--[[
    client.lua – Einreise-System (ESX Legacy)

    Aufgaben des Clients:
      * Statusanzeige (Karten-Kreis, Warnhinweis, Erinnerung)
      * Nicht eingereiste Spieler beim Verlassen des Sperrradius zurückteleportieren
      * Einreisebeamten-Outfit anziehen / vorheriges Outfit wiederherstellen

    WICHTIG: Der Client entscheidet NIE über den Einreisestatus. Er bekommt ihn nur vom
    Server mitgeteilt ("einreise:syncStatus"). Selbst wenn jemand diese Variable fälscht,
    prüft der Server die Position unabhängig davon und setzt den Spieler zurück.
]]

local ESX = exports['es_extended']:getSharedObject()

-- nil = Status noch unbekannt, true = eingereist, false = nicht eingereist
local Entered = nil
local IsReturning = false
local RadiusBlip = nil
local LastReminder = 0

local OutfitActive = false
local SavedOutfit = nil

-- ============================================================================
--  HILFSFUNKTIONEN
-- ============================================================================

local function Dist2D(a, b)
    local dx, dy = a.x - b.x, a.y - b.y
    return math.sqrt(dx * dx + dy * dy)
end

local function Notify(msg, nType)
    ESX.ShowNotification(msg, nType or 'info')
end

local function DeepCopy(value)
    if type(value) ~= 'table' then return value end
    local copy = {}
    for k, v in pairs(value) do
        copy[k] = DeepCopy(v)
    end
    return copy
end

local function DrawHint(text)
    SetTextFont(4)
    SetTextScale(0.0, 0.5)
    SetTextColour(255, 70, 70, 255)
    SetTextCentre(true)
    SetTextOutline()
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.5, 0.88)
end

-- ============================================================================
--  KARTEN-KREIS
-- ============================================================================

local function UpdateBlip()
    if RadiusBlip then
        RemoveBlip(RadiusBlip)
        RadiusBlip = nil
    end

    if Entered == false and Config.Blip.enabled then
        local c = Config.Airport.center
        RadiusBlip = AddBlipForRadius(c.x, c.y, c.z, Config.Airport.radius + 0.0)
        SetBlipColour(RadiusBlip, Config.Blip.color)
        SetBlipAlpha(RadiusBlip, Config.Blip.alpha)
    end
end

-- ============================================================================
--  ZURÜCKTELEPORTIEREN
-- ============================================================================

local function ReturnToEntryArea(reason)
    if IsReturning then return end
    IsReturning = true

    local fadedByUs = false

    local ok, err = pcall(function()
        local ped = PlayerPedId()
        local p = Config.ReturnPoint

        if Config.Client.fade and IsScreenFadedIn() then
            DoScreenFadeOut(400)
            local timeout = GetGameTimer() + 1500
            while not IsScreenFadedOut() and GetGameTimer() < timeout do
                Wait(0)
            end
            fadedByUs = true
        end

        -- Fahrer nehmen ihr Fahrzeug mit, alle anderen werden einzeln gesetzt
        local entity = ped
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
            entity = veh
        end

        RequestCollisionAtCoord(p.x, p.y, p.z)
        SetEntityCoords(entity, p.x, p.y, p.z, false, false, false, false)
        SetEntityHeading(entity, p.w)
        if entity ~= ped then
            SetEntityVelocity(entity, 0.0, 0.0, 0.0)
            SetVehicleOnGroundProperly(entity)
        end

        -- Warten, bis der Boden geladen ist (max. 3 Sekunden)
        local timeout = GetGameTimer() + 3000
        while not HasCollisionLoadedAroundEntity(entity) and GetGameTimer() < timeout do
            RequestCollisionAtCoord(p.x, p.y, p.z)
            Wait(0)
        end
    end)

    -- Immer aufräumen, auch bei einem Fehler: Bildschirm zurückholen, Sperre lösen
    if fadedByUs then DoScreenFadeIn(500) end
    IsReturning = false

    if not ok then
        print(('[einreise] Fehler beim Zurückteleportieren: %s'):format(tostring(err)))
        return
    end

    if reason then Notify(reason, 'error') end
end

-- ============================================================================
--  STATUS-SYNCHRONISATION (kommt ausschließlich vom Server)
-- ============================================================================

RegisterNetEvent('einreise:syncStatus', function(entered)
    local wasEntered = Entered
    Entered = (entered == true)
    UpdateBlip()

    if Entered == false and wasEntered ~= false then
        LastReminder = 0 -- sofort einen Hinweis anzeigen
    end
end)

-- Der Server fordert den Spieler auf, sich zurückzusetzen (Sicherheitsprüfung)
RegisterNetEvent('einreise:forceReturn', function()
    if Entered == false then
        ReturnToEntryArea(Config.Text.left_area)
    end
end)

local function RequestStatus()
    TriggerServerEvent('einreise:requestStatus')
end

RegisterNetEvent('esx:playerLoaded', function()
    RequestStatus()
end)

AddEventHandler('onClientResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if ESX.IsPlayerLoaded() then
        RequestStatus()
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if RadiusBlip then RemoveBlip(RadiusBlip) end
end)

-- ============================================================================
--  HAUPTSCHLEIFE: Sperrradius überwachen (nur wenn nicht eingereist)
-- ============================================================================

CreateThread(function()
    while true do
        local sleep = Config.Client.checkInterval

        if Entered == false and not IsReturning then
            local ped = PlayerPedId()

            if not IsEntityDead(ped) then
                local dist = Dist2D(GetEntityCoords(ped), Config.Airport.center)
                local radius = Config.Airport.radius

                if dist > radius then
                    ReturnToEntryArea(Config.Text.left_area)
                else
                    -- Warnhinweis kurz vor der Grenze (jeden Frame zeichnen)
                    if dist > radius - Config.Client.warnDistance then
                        sleep = 0
                        DrawHint(Config.Text.warn_border)
                    end

                    -- Regelmäßige Erinnerung
                    local interval = Config.Client.reminderInterval
                    if interval > 0 and (GetGameTimer() - LastReminder) > interval * 1000 then
                        LastReminder = GetGameTimer()
                        Notify(Config.Text.not_entered_info)
                    end
                end
            end
        end

        Wait(sleep)
    end
end)

-- ============================================================================
--  EINREISEBEAMTEN-OUTFIT
-- ============================================================================
-- Der Server prüft die Berechtigung (Befehl /einreiseoutfit) und löst dann
-- "einreise:outfit" aus. Das Outfit wird nur lokal angezogen und NICHT in der
-- Datenbank gespeichert – nach einem Relog gilt wieder das normale Outfit.

-- Zuordnung der skinchanger-Namen zu GTA-Komponenten/Props (für den nativen Modus)
local ComponentIds = {
    mask = 1, arms = 3, pants = 4, bags = 5, shoes = 6,
    chain = 7, tshirt = 8, bproof = 9, decals = 10, torso = 11
}
local PropIds = { helmet = 0, glasses = 1, ears = 2 }
local SnapshotProps = { 0, 1, 2, 6, 7 }

local function GetOutfitSystem()
    local sys = Config.OutfitSystem
    if sys == 'native' then return 'native' end

    local available = GetResourceState('skinchanger') == 'started'
    if available then return 'skinchanger' end
    return 'native'
end

-- Aktuelles Aussehen merken (nativ)
local function SnapshotNative(ped)
    local snap = { components = {}, props = {} }

    for i = 0, 11 do
        snap.components[i] = {
            GetPedDrawableVariation(ped, i),
            GetPedTextureVariation(ped, i),
            GetPedPaletteVariation(ped, i)
        }
    end

    for _, i in ipairs(SnapshotProps) do
        snap.props[i] = { GetPedPropIndex(ped, i), GetPedPropTextureIndex(ped, i) }
    end

    return snap
end

local function RestoreNative(ped, snap)
    for i, c in pairs(snap.components) do
        SetPedComponentVariation(ped, i, c[1], c[2], c[3])
    end

    for i, p in pairs(snap.props) do
        if p[1] == -1 then
            ClearPedProp(ped, i)
        else
            SetPedPropIndex(ped, i, p[1], p[2], true)
        end
    end
end

local function ApplyNativeOutfit(ped, clothes)
    for name, compId in pairs(ComponentIds) do
        local drawable = clothes[name .. '_1']
        if name == 'arms' then drawable = clothes['arms'] end

        if drawable ~= nil then
            SetPedComponentVariation(ped, compId, drawable, clothes[name .. '_2'] or 0, 2)
        end
    end

    for name, propId in pairs(PropIds) do
        local drawable = clothes[name .. '_1']

        if drawable ~= nil then
            if drawable < 0 then
                ClearPedProp(ped, propId)
            else
                SetPedPropIndex(ped, propId, drawable, clothes[name .. '_2'] or 0, true)
            end
        end
    end
end

local function WearOfficerOutfit()
    if GetOutfitSystem() == 'skinchanger' then
        TriggerEvent('skinchanger:getSkin', function(skin)
            if not skin then
                Notify(Config.Text.outfit_unsupported, 'error')
                return
            end

            -- Vorheriges Outfit als echte Kopie sichern (nie die Originaltabelle behalten)
            SavedOutfit = { system = 'skinchanger', skin = DeepCopy(skin) }

            local clothes = (skin.sex == 0) and Config.Outfit.male or Config.Outfit.female
            TriggerEvent('skinchanger:loadClothes', skin, clothes)

            OutfitActive = true
            Notify(Config.Text.outfit_on, 'success')
        end)
    else
        local ped = PlayerPedId()
        local model = GetEntityModel(ped)
        local clothes

        if model == GetHashKey('mp_m_freemode_01') then
            clothes = Config.Outfit.male
        elseif model == GetHashKey('mp_f_freemode_01') then
            clothes = Config.Outfit.female
        else
            Notify(Config.Text.outfit_unsupported, 'error')
            return
        end

        SavedOutfit = { system = 'native', data = SnapshotNative(ped) }
        ApplyNativeOutfit(ped, clothes)

        OutfitActive = true
        Notify(Config.Text.outfit_on, 'success')
    end
end

local function RestoreOutfit()
    if not OutfitActive or not SavedOutfit then
        OutfitActive = false
        SavedOutfit = nil
        Notify(Config.Text.outfit_none, 'error')
        return
    end

    if SavedOutfit.system == 'skinchanger' then
        TriggerEvent('skinchanger:loadSkin', DeepCopy(SavedOutfit.skin))
    else
        RestoreNative(PlayerPedId(), SavedOutfit.data)
    end

    OutfitActive = false
    SavedOutfit = nil
    Notify(Config.Text.outfit_off, 'success')
end

-- mode: 'toggle' (an/aus im Wechsel) oder 'restore' (immer wiederherstellen)
RegisterNetEvent('einreise:outfit', function(mode)
    if mode == 'restore' then
        RestoreOutfit()
    elseif OutfitActive then
        RestoreOutfit()
    else
        WearOfficerOutfit()
    end
end)

-- Beim Charakterwechsel/Logout das alte Outfit zurückholen und Status zurücksetzen
RegisterNetEvent('esx:onPlayerLogout', function()
    if OutfitActive then RestoreOutfit() end
    Entered = nil
    UpdateBlip()
end)

-- ============================================================================
--  EXPORT
-- ============================================================================
-- exports['einreise']:IsEntered()  -> true / false / nil (Status unbekannt)
exports('IsEntered', function()
    return Entered
end)
