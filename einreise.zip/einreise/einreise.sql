-- ============================================================================
--  Einreise-System – Datenbanktabelle
--  Einmalig in die ESX-Datenbank importieren (z. B. HeidiSQL, phpMyAdmin, DBeaver).
-- ============================================================================

CREATE TABLE IF NOT EXISTS `einreise_status` (
    `identifier` VARCHAR(60)  NOT NULL                          COMMENT 'ESX-Identifier des Charakters (users.identifier)',
    `entered`    TINYINT(1)   NOT NULL DEFAULT 0                COMMENT '0 = nicht eingereist, 1 = eingereist',
    `entered_by` VARCHAR(60)  NULL     DEFAULT NULL             COMMENT 'Identifier des Teamlers (oder "console") bzw. "export"',
    `entered_at` TIMESTAMP    NULL     DEFAULT NULL             COMMENT 'Zeitpunkt der Einreise',
    `updated_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`identifier`),
    KEY `idx_entered` (`entered`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
--  OPTIONAL: Bereits vorhandene Charaktere als "eingereist" markieren.
--  Ohne diesen Schritt gelten ALLE bestehenden Spieler beim ersten Login als
--  nicht eingereist (sofern Config.DefaultEntered = false ist).
--  Zum Ausführen die beiden Kommentarzeichen am Zeilenanfang entfernen.
-- ----------------------------------------------------------------------------
-- INSERT IGNORE INTO `einreise_status` (`identifier`, `entered`, `entered_by`, `entered_at`)
-- SELECT `identifier`, 1, 'migration', NOW() FROM `users`;
