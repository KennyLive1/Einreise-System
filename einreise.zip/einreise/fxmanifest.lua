fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'einreise'
description 'Einreisesystem für ESX Legacy'
author 'Nova Development'
version '1.0.0'

-- Voraussetzungen: es_extended (ESX Legacy), oxmysql und OneSync (Standard bei modernen Servern)
dependencies {
    'es_extended',
    'oxmysql'
}

shared_script 'Config.lua'

client_script 'client.lua'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}
