--[[
    server.lua – Einreise-System (ESX Legacy, oxmysql)

    Der Server ist die einzige Instanz, die den Einreisestatus ändern darf:
      * Status wird dauerhaft in der Tabelle `einreise_status` gespeichert
      * Befehle werden serverseitig auf Berechtigung geprüft
      * Nicht eingereiste Spieler werden unabhängig vom Client überwacht (OneSync)
]]

local ESX = exports['es_extended']:getSharedObject()
local RESOURCE = GetCurrentResourceName()

-- [source] = { identifier = 'char1:abc...', entered = true/false }
local States = {}
local Violations = {}      -- [source] = Anzahl Verstöße in Folge (Sicherheitsprüfung)
local StatusCooldown = {}  -- Spam-Schutz für "einreise:requestStatus"
local OutfitCooldown = {}  -- Spam-Schutz für /einreiseoutfit

-- ============================================================================
--  HILFSFUNKTIONEN
-- ============================================================================

local function T(key, ...)
    local text = Config.Text[key] or key
    if select('#', ...) > 0 then
        return text:format(...)
    end
    return text
end

local function DebugPrint(msg, ...)
    if not Config.Debug then return end
    if select('#', ...) > 0 then msg = msg:format(...) end
    print(('^3[%s][DEBUG]^7 %s'):format(RESOURCE, msg))
end

local function Dist2D(a, b)
    local dx, dy = a.x - b.x, a.y - b.y
    return math.sqrt(dx * dx + dy * dy)
end

-- Nachricht an einen Spieler (oder in die Serverkonsole, wenn src == 0)
local function Notify(src, msg, nType)
    if src == 0 then
        print(('[%s] %s'):format(RESOURCE, msg))
        return
    end
    TriggerClientEvent('esx:showNotification', src, msg, nType or 'info')
end

-- Kennung und Anzeigename des ausführenden Teamlers
local function GetActor(src)
    if src == 0 then return 'console', 'Konsole' end
    local xPlayer = ESX.GetPlayerFromId(src)
    return (xPlayer and xPlayer.identifier) or ('src:' .. tostring(src)), (GetPlayerName(src) or ('ID ' .. tostring(src)))
end

local function PlayerLabel(id)
    local xPlayer = ESX.GetPlayerFromId(id)
    if xPlayer and xPlayer.getName then
        return xPlayer.getName()
    end
    return GetPlayerName(id) or ('ID ' .. tostring(id))
end

-- true, wenn der Aufruf zu früh kommt (ms seit letztem Aufruf)
local function OnCooldown(tbl, src, ms)
    local now = GetGameTimer()
    if tbl[src] and (now - tbl[src]) < ms then return true end
    tbl[src] = now
    return false
end

-- Konsolen- und optionaler Discord-Log
local function LogEvent(title, message, color)
    print(('^5[%s]^7 %s: %s'):format(RESOURCE, title, message))

    if not Config.Webhook.enabled or not Config.Webhook.url or Config.Webhook.url == '' then return end

    PerformHttpRequest(Config.Webhook.url, function() end, 'POST', json.encode({
        username = Config.Webhook.name,
        embeds = {{
            title = title,
            description = message,
            color = color or 3447003,
            footer = { text = os.date('%d.%m.%Y %H:%M:%S') }
        }}
    }), { ['Content-Type'] = 'application/json' })
end

-- ============================================================================
--  BERECHTIGUNGEN
-- ============================================================================

local function HasPermission(src, perm)
    if src == 0 then return true end -- Serverkonsole
    if not perm then return false end

    -- 1. ACE-Berechtigung
    if perm.ace and perm.ace ~= '' and IsPlayerAceAllowed(src, perm.ace) then
        return true
    end

    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return false end

    -- 2. ESX-Gruppe
    if perm.groups then
        local group = xPlayer.getGroup()
        for _, g in ipairs(perm.groups) do
            if g == group then return true end
        end
    end

    -- 3. Job + Mindest-Rang
    if perm.jobs and xPlayer.job then
        local minGrade = perm.jobs[xPlayer.job.name]
        if minGrade ~= nil and (xPlayer.job.grade or 0) >= minGrade then
            return true
        end
    end

    return false
end

-- ============================================================================
--  STATUS LADEN / SPEICHERN (oxmysql)
-- ============================================================================

-- Liefert den (zwischengespeicherten) Status eines Spielers. Lädt ihn bei Bedarf aus der
-- Datenbank und legt für neue Charaktere einen Eintrag an.
local function EnsureState(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return nil end

    local identifier = xPlayer.identifier
    local cached = States[src]
    if cached and cached.identifier == identifier then
        return cached
    end

    local ok, row = pcall(MySQL.single.await, 'SELECT `entered` FROM `einreise_status` WHERE `identifier` = ?', { identifier })
    if not ok then
        print(('^1[%s] Datenbankfehler beim Laden von %s^7'):format(RESOURCE, identifier))
        return nil
    end

    local entered
    if row then
        entered = (row.entered == 1 or row.entered == true)
    else
        entered = Config.DefaultEntered == true
        pcall(MySQL.insert.await,
            'INSERT IGNORE INTO `einreise_status` (`identifier`, `entered`) VALUES (?, ?)',
            { identifier, entered and 1 or 0 })
    end

    -- Falls parallel schon jemand geladen hat, dessen Ergebnis behalten
    local again = States[src]
    if again and again.identifier == identifier then
        return again
    end

    States[src] = { identifier = identifier, entered = entered }
    DebugPrint('Status geladen: %s (%s) -> %s', tostring(src), identifier, tostring(entered))
    return States[src]
end

-- Setzt den Status dauerhaft in der Datenbank und informiert den Client.
local function SetEntered(targetSrc, entered, byIdentifier)
    local state = EnsureState(targetSrc)
    if not state then return false end

    local flag = entered and 1 or 0
    local ok, result = pcall(MySQL.update.await, [[
        INSERT INTO `einreise_status` (`identifier`, `entered`, `entered_by`, `entered_at`)
        VALUES (?, ?, ?, IF(? = 1, NOW(), NULL))
        ON DUPLICATE KEY UPDATE
            `entered`    = VALUES(`entered`),
            `entered_by` = VALUES(`entered_by`),
            `entered_at` = VALUES(`entered_at`)
    ]], { state.identifier, flag, byIdentifier or 'unbekannt', flag })

    if not ok or result == nil then
        print(('^1[%s] Fehler beim Speichern des Einreisestatus für %s^7'):format(RESOURCE, state.identifier))
        return false
    end

    state.entered = entered
    Violations[targetSrc] = nil
    TriggerClientEvent('einreise:syncStatus', targetSrc, entered)
    return true
end

-- ============================================================================
--  EVENTS
-- ============================================================================

-- Chat-Vorschläge nur für Berechtigte
local function SendSuggestions(src)
    if HasPermission(src, Config.Permissions.manage) then
        local idArg = {{ name = 'id', help = T('sugg_id_help') }}
        TriggerClientEvent('chat:addSuggestion', src, '/' .. Config.Commands.grant, T('sugg_grant'), idArg)
        TriggerClientEvent('chat:addSuggestion', src, '/' .. Config.Commands.revoke, T('sugg_revoke'), idArg)
        TriggerClientEvent('chat:addSuggestion', src, '/' .. Config.Commands.status, T('sugg_status'), idArg)
    end

    if HasPermission(src, Config.Permissions.outfit) then
        TriggerClientEvent('chat:addSuggestion', src, '/' .. Config.Commands.outfit, T('sugg_outfit'),
            {{ name = 'aus', help = T('sugg_outfit_help') }})
    end
end

-- Spieler (bzw. Charakter) wurde geladen
AddEventHandler('esx:playerLoaded', function(playerId)
    States[playerId] = nil -- bei Charakterwechsel sauber neu laden
    Violations[playerId] = nil

    local state = EnsureState(playerId)
    if state then
        TriggerClientEvent('einreise:syncStatus', playerId, state.entered)
    end

    SendSuggestions(playerId)
end)

-- Der Client darf NUR seinen eigenen Status abfragen (lesend) – nie setzen.
RegisterNetEvent('einreise:requestStatus', function()
    local src = source
    if OnCooldown(StatusCooldown, src, 2000) then return end

    local state = EnsureState(src)
    if state then
        TriggerClientEvent('einreise:syncStatus', src, state.entered)
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    States[src] = nil
    Violations[src] = nil
    StatusCooldown[src] = nil
    OutfitCooldown[src] = nil
end)

-- ============================================================================
--  START: Tabelle prüfen und bereits online befindliche Spieler synchronisieren
-- ============================================================================

MySQL.ready(function()
    local ok, row = pcall(MySQL.single.await, "SHOW TABLES LIKE 'einreise_status'")
    if not ok or not row then
        print(('^1[%s] FEHLER: Tabelle "einreise_status" fehlt! Bitte einreise.sql importieren.^7'):format(RESOURCE))
        return
    end

    -- Resource wurde (neu) gestartet, während Spieler online sind
    for _, id in ipairs(ESX.GetPlayers()) do
        CreateThread(function()
            local state = EnsureState(id)
            if state then
                TriggerClientEvent('einreise:syncStatus', id, state.entered)
                SendSuggestions(id)
            end
        end)
    end
end)

-- ============================================================================
--  SERVERSEITIGE SICHERHEITSPRÜFUNG
-- ============================================================================
-- Prüft in festen Abständen die echte Position aller nicht eingereisten Spieler.
-- 1. Verstoß  : Client wird aufgefordert, sich zurückzusetzen
-- ab forceAfter: Server teleportiert den Spieler selbst (Schutz vor manipulierten Clients)

local function CheckPlayer(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return end
    if GetEntityHealth(ped) <= 0 then return end -- Tote werden nicht verschoben

    local coords = GetEntityCoords(ped)
    if coords.x == 0.0 and coords.y == 0.0 then return end -- noch nicht gespawnt

    local limit = Config.Airport.radius + Config.Server.tolerance
    if Dist2D(coords, Config.Airport.center) <= limit then
        Violations[src] = nil
        return
    end

    Violations[src] = (Violations[src] or 0) + 1

    if Violations[src] < Config.Server.forceAfter then
        TriggerClientEvent('einreise:forceReturn', src)
        return
    end

    -- Client hat nicht reagiert -> Server setzt den Spieler selbst zurück
    local p = Config.ReturnPoint
    SetEntityCoords(ped, p.x, p.y, p.z, false, false, false, false)
    SetEntityHeading(ped, p.w)
    Violations[src] = nil

    Notify(src, T('left_area'), 'error')

    local _, actorName = GetActor(src)
    LogEvent('Einreise: Server-Rücksetzung',
        ('%s (ID %s) war nicht eingereist und außerhalb des Flughafens. Der Server hat ihn zurückgesetzt (mögliche Manipulation).')
            :format(actorName, src), 15548997)
end

CreateThread(function()
    while true do
        Wait(Config.Server.checkInterval)

        for src, state in pairs(States) do
            local xPlayer = ESX.GetPlayerFromId(src)

            if not xPlayer or xPlayer.identifier ~= state.identifier then
                -- Spieler offline oder Charakter gewechselt -> Cache verwerfen
                States[src] = nil
                Violations[src] = nil
            elseif not state.entered then
                CheckPlayer(src)
            end
        end
    end
end)

-- ============================================================================
--  BEFEHLE (Teamler)
-- ============================================================================

-- Prüft Berechtigung und Ziel. Gibt targetId und Status zurück oder nil (Fehler wurde gemeldet).
local function ResolveTarget(src, args, commandName, isGrant)
    if not HasPermission(src, Config.Permissions.manage) then
        Notify(src, T('no_permission'), 'error')
        return nil
    end

    local targetId = tonumber(args[1])
    if not targetId or targetId % 1 ~= 0 or targetId < 1 then
        Notify(src, T('usage', commandName), 'error')
        return nil
    end

    if isGrant and targetId == src and not Config.AllowSelfGrant then
        Notify(src, T('self_denied'), 'error')
        return nil
    end

    if not ESX.GetPlayerFromId(targetId) then
        Notify(src, T('target_offline', targetId), 'error')
        return nil
    end

    local state = EnsureState(targetId)
    if not state then
        Notify(src, T('db_error'), 'error')
        return nil
    end

    return targetId, state
end

-- /einreise [Spieler-ID]
RegisterCommand(Config.Commands.grant, function(src, args)
    local targetId, state = ResolveTarget(src, args, Config.Commands.grant, true)
    if not targetId then return end

    local label = PlayerLabel(targetId)

    if state.entered then
        return Notify(src, T('already_entered', label, targetId), 'error')
    end

    local actorId, actorName = GetActor(src)
    if not SetEntered(targetId, true, actorId) then
        return Notify(src, T('db_error'), 'error')
    end

    Notify(src, T('granted_staff', label, targetId), 'success')
    Notify(targetId, T('granted_target', actorName), 'success')
    LogEvent('Einreise freigegeben',
        ('**%s** (%s) hat **%s** (ID %s, %s) einreisen lassen.'):format(actorName, actorId, label, targetId, state.identifier),
        5763719)
end, false)

-- /einreiseentzug [Spieler-ID]
RegisterCommand(Config.Commands.revoke, function(src, args)
    local targetId, state = ResolveTarget(src, args, Config.Commands.revoke, false)
    if not targetId then return end

    local label = PlayerLabel(targetId)

    if not state.entered then
        return Notify(src, T('not_entered', label, targetId), 'error')
    end

    local actorId, actorName = GetActor(src)
    if not SetEntered(targetId, false, actorId) then
        return Notify(src, T('db_error'), 'error')
    end

    Notify(src, T('revoked_staff', label, targetId), 'success')
    Notify(targetId, T('revoked_target'), 'error')
    LogEvent('Einreise widerrufen',
        ('**%s** (%s) hat die Einreise von **%s** (ID %s, %s) widerrufen.'):format(actorName, actorId, label, targetId, state.identifier),
        15548997)
end, false)

-- /einreisestatus [Spieler-ID]
RegisterCommand(Config.Commands.status, function(src, args)
    local targetId, state = ResolveTarget(src, args, Config.Commands.status, false)
    if not targetId then return end

    local label = PlayerLabel(targetId)
    local key = state.entered and 'status_entered' or 'status_pending'
    Notify(src, T(key, label, targetId), state.entered and 'success' or 'info')
end, false)

-- ============================================================================
--  BEFEHL /einreiseoutfit (geschützt)
-- ============================================================================
-- Die Berechtigung wird hier auf dem Server geprüft. Nur wenn sie vorliegt,
-- wird dem Client der Auftrag zum Umziehen geschickt.

RegisterCommand(Config.Commands.outfit, function(src, args)
    if src == 0 then
        return print(('[%s] %s'):format(RESOURCE, T('outfit_console')))
    end

    if not HasPermission(src, Config.Permissions.outfit) then
        return Notify(src, T('no_permission'), 'error')
    end

    if OnCooldown(OutfitCooldown, src, 2000) then
        return Notify(src, T('outfit_cooldown'), 'error')
    end

    local sub = args[1] and args[1]:lower() or nil
    local mode = 'toggle'
    if sub == 'aus' or sub == 'zurueck' or sub == 'zurück' or sub == 'reset' or sub == 'restore' then
        mode = 'restore'
    end

    TriggerClientEvent('einreise:outfit', src, mode)
end, false)

-- ============================================================================
--  EXPORTS für andere Server-Skripte
-- ============================================================================
-- exports['einreise']:IsEntered(source)                    -> true / false
-- exports['einreise']:SetEntered(source, true/false, wer)  -> true bei Erfolg

exports('IsEntered', function(src)
    local state = States[src]
    return state ~= nil and state.entered == true
end)

exports('SetEntered', function(src, entered, by)
    return SetEntered(src, entered == true, by or 'export')
end)
